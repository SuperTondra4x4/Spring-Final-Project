
   
package com.promineotech.baseball.service;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.promineotech.baseball.dao.PlayerDao;
import com.promineotech.baseball.entity.Player;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class DefaultPlayerService implements PlayerService {
	
	@Autowired
	private PlayerDao playerDao;

  @Override
  public List<Player> getPlayer(String first_name, String last_name) {
	    log.info("Service Player First Name = {}, Last Name = {}", first_name, last_name);
	  
	    List<Player> players = playerDao.getPlayer(first_name, last_name);
	   
	    return players;
  }

}