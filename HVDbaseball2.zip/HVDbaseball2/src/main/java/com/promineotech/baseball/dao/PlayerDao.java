package com.promineotech.baseball.dao;

import java.util.List;


import com.promineotech.baseball.entity.Player;

public interface PlayerDao {
	
	  List<Player> getPlayer(String first_name, String last_name);


}
