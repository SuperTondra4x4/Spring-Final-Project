package com.promineotech.baseball;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class BaseballApp {
	public static void main(String[] args){
		SpringApplication.run(BaseballApp.class, args);
		
	}

}
