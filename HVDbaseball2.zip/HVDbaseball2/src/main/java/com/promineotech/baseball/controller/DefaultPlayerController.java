package com.promineotech.baseball.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.promineotech.baseball.entity.Player;
import com.promineotech.baseball.service.DefaultPlayerService;
import com.promineotech.baseball.service.PlayerService;

import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
public class DefaultPlayerController implements PlayerController {
	
	  @Autowired
	  private PlayerService playerService;

	@Override
	  public List<Player> getPlayer(String first_name, String last_name) {
		log.info("Controller Player First Name= {}, Last Name= {}", first_name, last_name);
	    return playerService.getPlayer(first_name, last_name);
	}

}
