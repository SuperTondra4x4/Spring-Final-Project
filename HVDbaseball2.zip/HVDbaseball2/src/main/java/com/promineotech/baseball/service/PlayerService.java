package com.promineotech.baseball.service;

import java.util.List;

import com.promineotech.baseball.entity.Player;

public interface PlayerService {

  List<Player> getPlayer(String first_name, String last_name);

}