package com.promineotech.baseball.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.promineotech.baseball.entity.Player;
import com.promineotech.baseball.entity.PlayerPosition;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DefaultPlayerDao implements PlayerDao{
	
	  @Autowired
	  private NamedParameterJdbcTemplate jdbcTemplate;
	
	@Override
	  public List<Player> getPlayer(String first_name, String last_name) {
	    log.info("Dao Players First Name = {}, Last Name = {}", first_name, last_name);
	    
	    String sql = "SELECT * FROM players WHERE first_name = :first_name AND last_name = :last_name";
	    
	    Map<String, Object> parms = new HashMap<>();
	    
	    parms.put("first_name", first_name);
	    parms.put("last_name", last_name);
	    
	    
	    return jdbcTemplate.query(sql, parms, new RowMapper<>() {
	    	
	        @Override
	        public Player mapRow(ResultSet rs, int rowNum) throws SQLException {
	        	
	       
	          return Player.builder()
	              .first_name(rs.getString("first_name"))
	              .last_name(rs.getString("last_name"))
	              .player_pk(rs.getInt("player_pk"))
	              .team_fk(rs.getInt("team_fk"))
	              .build();
	         
	          
	        }});


}
}
