package com.promineotech.baseball.entity;


public enum TransactionType {
  SIGN, TRADE, RELEASE;
}
