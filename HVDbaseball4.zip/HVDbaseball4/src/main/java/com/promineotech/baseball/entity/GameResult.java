package com.promineotech.baseball.entity;


public enum GameResult {
  W, L;
}
