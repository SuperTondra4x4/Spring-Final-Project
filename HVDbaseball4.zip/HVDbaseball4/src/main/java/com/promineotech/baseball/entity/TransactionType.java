package com.promineotech.baseball.entity;


public enum TransactionType {
  Sign, Trade, Release;
}
