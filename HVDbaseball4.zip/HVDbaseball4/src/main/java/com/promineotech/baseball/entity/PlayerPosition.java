package com.promineotech.baseball.entity;

import java.util.HashMap;
import java.util.Map;

public enum PlayerPosition {

  PITCHER, CATCHER, FIRST, SECOND, THIRD, SHORT, LEFT, CENTER, RIGHT;
//  
//  private static final Map<String, PlayerPosition> BY_POSITION = new HashMap<>();
//  private static final Map< PlayerPosition, String> BY_STRING = new HashMap<>();
//  
//  static {
//    for (PlayerPosition p : values()) {
//      BY_POSITION.put(p.pos, p);
//    }
//  }
//  public final String pos;
//
//  public static PlayerPosition valueOfPos(String pos) { 
//    return BY_POSITION.get(pos); 
//    }
// 
//  @Override 
//  public String toString() { 
//      return this.pos; 
//  }
}
