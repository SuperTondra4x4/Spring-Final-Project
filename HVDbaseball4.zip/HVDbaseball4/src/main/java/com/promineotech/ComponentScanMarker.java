package com.promineotech;

public interface ComponentScanMarker {

}
